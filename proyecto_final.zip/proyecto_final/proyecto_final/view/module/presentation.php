  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <img src="view/img/bg.jpg" width="100%" height="100%">

    <h1> BIENVENIDO </h1>
  </div>
  <!-- /.content-wrapper -->