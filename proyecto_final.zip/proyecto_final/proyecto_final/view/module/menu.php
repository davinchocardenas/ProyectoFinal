    <!-- Left side column. contains the logo and sidebar -->
    <aside class="main-sidebar">
      <!-- sidebar: style can be found in sidebar.less -->
      <section class="sidebar">
        

        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu" data-widget="tree">
          <li class="">
          <li class="active treeview">
            <a href="#">
              <i class="fa fa-dashboard"></i> <span>proveedor</span>
              <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
              </span>
            </a>
            <ul class="treeview-menu">
            <li class="">
            <a href="proveedor">
              <i class="fa fa-user"></i>
              <span>crear</span>
            </a>
            <li class="">
            <a href="verP">
              <i class="fa fa-user"></i>
              <span>ver proveedores</span>
            </a>
          </li>
        </ul> 
      </section>
  <section class="sidebar">
        <ul class="sidebar-menu" data-widget="tree">
          <li class="">
          <li class="active treeview">
            <a href="#">
              <i class="fa fa-dashboard"></i> <span>usuario</span>
              <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
              </span>
            </a>
            <ul class="treeview-menu">
            <li class="">
            <a href="usuario">
              <i class="fa fa-user"></i>
              <span>crear</span>
            </a>
            <li class="registro">
            <a href="registro">
              <i class="fa fa-user"></i>
              <span>ver usuarios</span>
            </a>
          </li>
  </section>
      <!-- /.sidebar -->
    </aside>
    <div id="ohsnap"></div>